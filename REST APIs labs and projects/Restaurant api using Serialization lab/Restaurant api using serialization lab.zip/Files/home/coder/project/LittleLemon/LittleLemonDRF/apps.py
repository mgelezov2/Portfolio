from django.apps import AppConfig
from django.urls import path
from . import views

urlpatterns = [
    path('menu-items', views.MenuItemsView.as_view()),
    path('menu-items/<int:pk>', views.SingleMenuItemView.as_view()),
]

class LittlelemondrfConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'LittleLemonDRF'

