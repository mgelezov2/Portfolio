from django.contrib import admin
from .models import MenuItem
from .models import Category
from .models import LLUsers
from .models import MenuCart
from .models import Order
from .models import OrderedItems
# Register your models here.

admin.site.register(MenuItem)
admin.site.register(Category)
admin.site.register(LLUsers)
admin.site.register(MenuCart)
admin.site.register(Order)
admin.site.register(OrderedItems)