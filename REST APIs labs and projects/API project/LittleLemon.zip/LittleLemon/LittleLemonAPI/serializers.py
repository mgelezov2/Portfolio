from decimal import Decimal
from rest_framework import serializers
from .models import Category
from .models import LLUsers
from .models import MenuItem
from .models import MenuCart
from .models import Order
from .models import OrderedItems
from rest_framework.validators import UniqueTogetherValidator
from django.contrib.auth.models import User
#CATEGORY MODEL SERIALIZER
#TAKES ID AND NAME FIELDS
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name']
#MENU USERS MODEL SERIALIZER
#TAKES USERNAME, EMAIL, ID, CUSTOMER USERS(IF APPLICABLE), DELIVERY USERS(IF APPLICABLE) AND MANAGER USERS(IF APPLICABLE) FIELDS
class MenuUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = LLUsers
        fields = ['username', 'email', 'id', 'customer_user', 'delivery_user', 'manager_user']

#MENU CART MODEL SERIALIZER
#TAKES ID, USER, MENU ITEM AND QUANTITY FIELDS
class MenuCartSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuCart
        fields = ['id', 'user', 'menu_item', 'quantity']

#MENU ITEM MODEL SERIALIZER
#TAKES ID, NAME, PRICE, INVENTORY AND CATEGORY FIELDS
class MenuItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuItem
        fields = ['id', 'name', 'price', 'inventory', 'category']

#ORDERED ITEMS MODEL SERIALIZER
#TAKES ID, ORDER, MENU ITEM AND QUANTITY FIELDS
class OrderedItemsSerializer(serializers.ModelSerializer):
    model = OrderedItems
    fields = ['id', 'order', 'menu_item', 'quantity']

#ORDER MODEL SERIALIZER
#TAKES ID, USER, STATUS AND DELIVERY USER FIELDS
class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = ['id', 'user', 'status', 'delivery_user']
        
#LLUSERS MODEL SERIALIZER
#TAKES USER DETAILS FROM USERNAME, EMAIL, ID, CUSTOMER USER(IF APPLICABLE), MANAGER USER(IF APPLICABLE), DELIVERY USER(IF APPLICABLE) FIELDS
class LLUsersSerializers(serializers.ModelSerializer):
    class Meta:
        model = LLUsers
        fields = ['username','email','id','customer_user','manager_user','delivery_user']