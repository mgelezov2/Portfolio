from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from .models import MenuItem
from .models import MenuCart
from .models import Order
from .models import LLUsers
from .models import OrderedItems
from .serializers import MenuItemSerializer
from .serializers import MenuCartSerializer
from .serializers import OrderSerializer
from.serializers import LLUsersSerializers
from .serializers import OrderedItemsSerializer
from django.shortcuts import get_object_or_404
from rest_framework import permissions, status
from django.contrib.auth import get_user_model
from rest_framework.permissions import IsAuthenticated


#MENU INFO FUNCTION
#PROVIDES ITEM DETAILS SUCH AS AVAILABILITY OR REQUEST A SPECIFIC ITEM
@api_view(['GET','PUT','DELETE','PATCH'])
@permission_classes([IsAuthenticated])
def menu_info(pk, request):
    try:
        menu_info = MenuItem.objects.get(pk=pk)
    except MenuItem.DoesNotExist:
        return Response({'message': 'Item is unavailable on listing'}, status=status.HTTP_404_NOT_FOUND)
    if request.method == 'GET':
        serializer = MenuItemSerializer(menu_info)
        return Response(serializer.data)
    if request.method in ['DELETE', 'PUT', 'PATCH']:
        if not request.user.manager_user:
            return Response({'message': 'You are trying to access or edit information as an unauthorized user'}, status=status.HTTP_403_FORBIDDEN)
        if request.method == 'DELETE':
            menu_info.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        serializer = MenuItemSerializer(menu_info, data=request.data, partial=(request.method == 'PATCH'))
        if serializer.is_valid:
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#@api_view()
#def single_item(request, id):
 #   item = get_object_or_404(MenuItem,pk=id)
 #   serialized_item = MenuItemSerializer(item)
 #   return Response(serialized_item.data)

#MENU ITEMS FUNCTION
#ALLOWS THE USER TO MAKE A LIST OF ITEMS AND DISPLAY A LIST OF ITEMS WHILE ALSO LIMITING ACCESS TO UNAUTHORIZED USERS
@api_view(['GET','POST'])
@permission_classes([IsAuthenticated])
def menu_items(request):
    if request.method == 'GET':
        items = MenuItem.objects.all()
        serializer = MenuItemSerializer(items, many=True)
        return Response(serializer.data)
    if request.method == 'POST':
        if not request.user.manager_user:
            return Response({'message': 'You are trying to access the menu as an unauthorized user'}, status=status.HTTP_403_FORBIDDEN)
        serializer = MenuItemSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)




#MENU ORDERS FUNCTION
#DISPLAYS THE USERS ORDERS TO THE DELIVERY USER AND THE MANAGER USER WHILE ALSO ALERTING THAT IF THERE ARE NO NEW ITEMS IN THE CART DISPLAY BAD REQUEST
@api_view(['POST','GET'])
@permission_classes([IsAuthenticated])
def menu_orders(request):
    user = request.user
    if request.method == 'GET':
        if user.manager_user:
            orders = Order.objects.all()
        elif user.delivery_user:
            orders = Order.objects.filter(delivery_crew=user)
        else:
            orders = Order.objects.filter(user=user)
        serializer = OrderSerializer(orders, many=True)
    if request.method == 'POST':
        items_in_cart = MenuCart.objects.filter(user=user)
        if not items_in_cart.exists():
            return Response({'message': 'There are no new items in cart'}, status=status.HTTP_400_BAD_REQUEST)
        order = Order.objects.create(user=user)
        for item_in_cart in items_in_cart:
            OrderedItems.objects.create(order=order, menu_item=item_in_cart.menu_item, quantity=item_in_cart.quantity)
        items_in_cart.delete()

        serializer = OrderSerializer(order)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    
#MENU CART FUNCTION
#ALLOWS THE USER THE USAGE OF AN ONLINE SHOPPING CART TO STORE ITEMS UNTIL THEY HAVE STOPPED TO FINALIZE THEIR PURCHASE OF ITEMS THEY HAVE CHOSEN
@api_view(['GET', 'DELETE', 'POST'])
@permission_classes([IsAuthenticated])
def menu_cart(request):
    if request.method == 'GET':
        menu_cart_items = MenuCart.objects.filter(user=request.user)
        serializer = MenuCartSerializer(menu_cart_items, many=True)
        return Response(serializer.data)
    if request.method == 'POST':
        cart_data = request.data.copy()
        cart_data['user'] = request.user.id
        serializer = MenuCartSerializer(data=cart_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    if request.method == 'DELETE':
        MenuCart.objects.filter(user=request.user).delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    

#MENU CREATING USER FUNCTION
#CHECKS TO SEE WHICH USER IS PRESENT AND IF USER IS NOT VALID 400 ERROR IS DISPLAYED
menu_user = get_user_model()
@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def menu_creating_user(request):
    serializer = LLUsersSerializers(data=request.data)
    if serializer.is_valid():
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#ORDER INFO FUNCTION
#DISPLAYS THE USER ORDER TO THE USER THAT HAS FINALIZED THEIR ORDER IF THE ORDER DOES NOT EXIST IT DISPLAYS 404, 
#IF USER IS UNAUTHORIZED THEN APPROPRIATE ERROR MESSAGES ARE DISPLAYED
@api_view(['DELETE','PUT', 'PATCH', 'GET'])
@permission_classes([IsAuthenticated])
def order_info(pk,request):
    try:
        order_info = Order.objects.get(pk=pk)
    except Order.DoesNotExist:
        return Response({'message': 'Order does not exist in the menu'}, status=status.HTTP_404_NOT_FOUND)
    user = request.user
    if request.method == 'GET':
        if order_info.user != user and not user.manager_user and not (user.delivery_user and order_info == user):
            return Response({'message': 'You are accessing info as an unauthorized user'}, status=status.HTTP_403_FORBIDDEN)
        serializer = OrderSerializer(order_info)
        return Response(serializer.data)
    if request.method in ['PATCH','PUT']:
        if not user.manager_user:
            return Response({'message': 'Cannot make changes as an unauthorized user'})
        serializer = OrderSerializer(order_info, data=request.data, partial=request.method == 'PATCH')
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    if request.method == 'DELETE':
        if not user.manager_user:
            return Response({'message':'You cannot use the delete request as an unauthorized user'}, status=status.HTTP_403_FORBIDDEN)
        order_info.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)