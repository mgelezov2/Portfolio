from django.urls import path
from . import views
#URL PATTERNS AND PATHS TO EACH VIEW
urlpatterns = [
    path('users/', views.menu_creating_user, name='user-create'),
    path('menu-items/', views.menu_items, name='menu-item-list'),
    path('menu-items/<int:pk>/', views.menu_info, name='menu-item-details'),
    path('cart/menu-items/', views.menu_cart, name='cart-menu-items'),
    path('orders/', views.menu_orders, name='orders'),
    path('orders/<int:pk>/', views.order_info, name='order-details')
]