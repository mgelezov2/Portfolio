from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractUser

#USERS IN GROUPS IN DJANGO ADMIN
class LLUsers(AbstractUser):
    user_permissions = models.ManyToManyField('auth.Permission', related_name='user_permissions', help_text='user permission', blank=True, verbose_name='user_permission')
    groups = models.ManyToManyField('auth.Group', related_name='user_group', help_text='group relation', blank=True, verbose_name='user_group')

    customer_user = models.BooleanField(default=True)
    manager_user = models.BooleanField(default=False)
    delivery_user = models.BooleanField(default=False)
    
#CATEGORY MODEL VARIABLES
class Category(models.Model):
    slug = models.SlugField
    title = models.CharField(max_length=255)
#MENU ITEM MODEL VARIABLES
class MenuItem(models.Model):
    name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    inventory = models.SmallIntegerField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
#MENU CART MODEL VARIABLES
class MenuCart(models.Model):
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    user = models.ForeignKey(LLUsers, on_delete=models.CASCADE)
#ORDER MODEL VARIABLES
class Order(models.Model):
    user = models.ForeignKey(LLUsers, on_delete=models.CASCADE)
    status = models.IntegerField(choices=[(0, 'Order Out For Delivery'), (1, 'Order has being delivered')])
    delivery_crew = models.ForeignKey(LLUsers, related_name='delivery_crew', on_delete=models.CASCADE)
#ORDERED ITEMS MODEL VARIABLES
class OrderedItems(models.Model):
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    order = models.ForeignKey(Order, on_delete=models.CASCADE)


    