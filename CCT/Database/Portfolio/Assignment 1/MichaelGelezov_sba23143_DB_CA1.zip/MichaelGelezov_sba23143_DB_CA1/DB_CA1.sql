#===============================================================================
#PARTS OF THE STEPS TAKEN ARE LABELED AS SUCH BELOW
# Question 1
# Question 2
# Question 3
# Question 4
# Question 5
# Question 6
#===============================================================================

#===============================================================================
#TO DO LIST
#NEED TO FIX PRIMARY KEY AND FOREIGN KEY RELATIONS BETWEEN TWO TABLES; ONE RELATION WAS IDENTIFIED AS ID BUT OUTPUTS ERROR

#NEED TO FIX DUPLICATED VALUES BEING USER NAMES WHEN JOINING COLUMNS FROM DIFFERENT TABLES;
#Username
#ID of the movie/series
#Genre

#NEED TO FIX DUPLICATED VALUES AND MISSING NAME VALUES, DURATION VALUES AND SEASON VALUES WHEN LOADING DATA INTO CSV(SPECIFICALLY movies table AND series table)
#BOTH movies table AND series table MUST BE MANUALLY IMPORTED AND VALUES SET TO THEIR APPROPRIATE COLUMNS THROUGH TABLE DATA IMPORT WIZARD
#===============================================================================

#===============================================================================
#FURTHER NOTE: User has to set a path to the directory where the generated data is stored for the tables to be populated otherwise it will prompt an error file not found
#===============================================================================

#DROP DATABASE Ireflex;
CREATE DATABASE Ireflex;
USE Ireflex;

# Question 1
CREATE TABLE users (
user_Name VARCHAR(35) NOT NULL,
user_firstName VARCHAR(35) NOT NULL,
user_Surname VARCHAR(35) NOT NULL,
Password VARCHAR(15) NOT NULL
);

#Question 2
LOAD DATA LOCAL INFILE '~/MYSQLScripts/GeneratedData/users table/users.csv'
INTO TABLE users
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n';

# Question 1 & Question 3
CREATE TABLE movies (
ID INT(6) NOT NULL,
movie_Name VARCHAR(35) NOT NULL,
movie_Genre VARCHAR(20) NOT NULL,
movie_Year YEAR NOT NULL,
movie_Duration TIME(3),
movie_Qualification ENUM('1','2','3','4','5'),
movie_protag_Name VARCHAR(35) NOT NULL,
movie_protag_Surname VARCHAR(35) NOT NULL
#PRIMARY KEY(ID)
);

#BUGGED
#Note:Creates duplicated year and does not populate first names and second names of protaginists only works 
#if manually imported and values are set to their appropriate columns through table data import wizard.

#Question 2 & Question 4
#LOAD DATA LOCAL INFILE '~/MYSQLScripts/GeneratedData/movies table/movies.csv'
#INTO TABLE movies
#FIELDS TERMINATED BY ','
#ENCLOSED BY '"'
#LINES TERMINATED BY '\n';

# Question 1 & Question 3
CREATE TABLE series(
series_ID INT(6) NOT NULL,
#ID INT(6) NOT NULL,
series_Name VARCHAR(35) NOT NULL,
series_Genre VARCHAR(20) NOT NULL,
series_Year YEAR NOT NULL,
series_Qualification ENUM('1','2','3','4','5'),
series_Protag_Name VARCHAR(35) NOT NULL,
series_Protag_Surname VARCHAR(35) NOT NULL,
series_Seasons INT(10)
#PRIMARY KEY(series_ID),
#FOREIGN KEY(ID) REFERENCES movies(ID)
);

#BUGGED
#Note:Creates duplicated year and does not populate first names, seasons and second names of protaginists only works 
#if manually imported and values are set to their appropriate columns through table data import wizard.

#Question 2 & Question 4
#LOAD DATA LOCAL INFILE '~/MYSQLScripts/GeneratedData/series table/series.csv'
#INTO TABLE series
#FIELDS TERMINATED BY ','
#ENCLOSED BY '"'
#LINES TERMINATED BY '\n';

# Question 1
CREATE TABLE actors(
Name VARCHAR(35) NOT NULL,
Surname VARCHAR(35) NOT NULL,
actor_Nationality VARCHAR(35) NOT NULL
);

#Question 2
LOAD DATA LOCAL INFILE '~/MYSQLScripts/GeneratedData/actors table/actor.csv'
INTO TABLE actors
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n';

# Question 1
CREATE TABLE directors(
Name VARCHAR(35) NOT NULL,
Surname VARCHAR(35) NOT NULL,
director_Nationality VARCHAR(35) NOT NULL
);

#Question 2
LOAD DATA LOCAL INFILE '~/MYSQLScripts/GeneratedData/directors table/director.csv'
INTO TABLE directors
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n';

#Question 5
#SELECT movie_Name, movie_protag_Name, movie_protag_Name_Surname, COUNT(*) AS movie_count FROM movies WHERE movie_protag_Name='Ryan' AND movie_protag_Name_Surname = 'Gosling' GROUP BY movie_Name, movie_protag_Name, movie_protag_Name_Surname ORDER BY movie_count DESC LIMIT 500

#Question 6
#SELECT movie_Name, movie_protag_Name, movie_protag_Name_Surname FROM movies WHERE movie_protag_Name='Natalie' AND movie_protag_Name_Surname='Portman' AND NOT EXISTS(SELECT *  FROM  series WHERE movies.movie_protag_Name_Surname = series.series_Protag_Surname);

#USER ACTIVITY REGISTERY
#SELECT user_Name, movies.ID, movies.movie_Genre FROM users JOIN movies;
#SELECT user_Name, series.series_ID, series.series_Genre FROM users JOIN series;


#TESTS TO CHECK IF DATA IS IN THE TABLES

 #SELECT * FROM users;
#SELECT * FROM movies;
#SELECT * FROM series;
 #SELECT * FROM actors;
 #SELECT * FROM directors;
 