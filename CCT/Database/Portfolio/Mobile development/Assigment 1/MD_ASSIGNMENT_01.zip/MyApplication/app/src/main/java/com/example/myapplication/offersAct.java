package com.example.myapplication;
//IMPORTS FOR OFFERS ACTIVITY
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
//OFFERS ACTIVITY CLASS THAT EXTENDS TO APPCOMPATACTIVITY
public class offersAct extends AppCompatActivity{
    //RESOURCES FOR THE OFFERS ACTIVITY
    //THESE ALLOW FOR VALUES TO BE DISPLAYED AND INTERACTIVE EXCEPT THESE HAVE DISCOUNTED PRICE VALUES
    //https://developer.android.com/reference/android/widget/TextView
    private TextView souvlakiItem, souvlakiItemDesc, souvlakiItemPriceOriginal, souvlakiItemPriceDiscounted;
    //https://developer.android.com/reference/android/widget/ImageView
    private ImageView souvlakiImg;
    //https://developer.android.com/develop/ui/views/components/button
    private Button souvlakiButton;
    //https://developer.android.com/reference/android/widget/TextView
    private TextView dolmadesItem, dolmadesItemDesc, dolmadesItemPriceOriginal, dolmadesItemPriceDiscounted;
    //https://developer.android.com/reference/android/widget/ImageView
    private ImageView dolmadesImg;
    //https://developer.android.com/develop/ui/views/components/button
    private Button dolmadesButton;
    //https://developer.android.com/reference/android/widget/TextView
    private TextView moussakaItem, moussakaItemDesc, moussakaItemPriceOriginal, moussakaItemPriceDiscounted;
    //https://developer.android.com/reference/android/widget/ImageView
    private ImageView moussakaImg;
    //https://developer.android.com/develop/ui/views/components/button
    private Button moussakaButton;
    //ONCREATE FUNCTION FOR OFFERS ACTIVITY
    @Override
    //https://developer.android.com/reference/android/app/Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offers_menu);
        //METHODS CALLED FOR OFFERS ACTIVITY
        //https://codegym.cc/groups/posts/how-to-call-a-method-in-java-
        offers_view_init();
        offers_listener_init();
        offers_discount_init();
    }
    //OFFERS VIEW TO DISPLAY THE DISCOUNTED MEALS FOR THE USER
    //https://www.w3schools.com/java/java_methods.asp
    private void offers_view_init() {
        //SOULVAKI FOOD ITEM VALUES
        //https://developer.android.com/reference/android/view/View
        souvlakiItem = findViewById(R.id.souvlaki_item);
        souvlakiItemDesc = findViewById(R.id.souvlaki_item_desc);
        souvlakiItemPriceOriginal = findViewById(R.id.souvlaki_item_price_original);
        souvlakiItemPriceDiscounted = findViewById(R.id.souvlaki_item_price_discounted);
        souvlakiImg = findViewById(R.id.souvlaki_img);
        souvlakiButton = findViewById(R.id.souvlaki_button);
        //DOLMADES FOOD ITEM VALUES
        //https://developer.android.com/reference/android/view/View
        dolmadesItem = findViewById(R.id.dolmades_item);
        dolmadesItemDesc = findViewById(R.id.dolmades_item_desc);
        dolmadesItemPriceOriginal = findViewById(R.id.dolmades_item_price_original);
        dolmadesItemPriceDiscounted = findViewById(R.id.dolmades_item_price_discounted);
        dolmadesImg = findViewById(R.id.dolmades_img);
        dolmadesButton = findViewById(R.id.dolmades_button);
        //MOUSSAKA FOOD ITEM VALUES
        //https://developer.android.com/reference/android/view/View
        moussakaItem = findViewById(R.id.moussaka_item);
        moussakaItemDesc = findViewById(R.id.moussaka_item_desc);
        moussakaItemPriceOriginal = findViewById(R.id.moussaka_item_price_original);
        moussakaItemPriceDiscounted = findViewById(R.id.moussaka_item_price_discounted);
        moussakaImg = findViewById(R.id.moussaka_img);
        moussakaButton = findViewById(R.id.moussaka_button);
    }
    //OFFERS BUTTON LISTENERS FOR PURCHASING THE FOOD
    //SOUVLAKI BUTTON LISTENER FOR PURCHASING SOUVLAKI
    //https://www.w3schools.com/java/java_methods.asp
    //https://stackoverflow.com/questions/25803727/android-setonclicklistener-method-how-does-it-work
    private void offers_listener_init() {
        souvlakiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                offers_purchase_init(v);
            }
        });
    //DOLMADES BUTTON LISTENER FOR PURHASING DOLMADES
        //https://www.w3schools.com/java/java_methods.asp
        //https://stackoverflow.com/questions/25803727/android-setonclicklistener-method-how-does-it-work
        dolmadesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                offers_purchase_init(v);
            }
        });
    //MOUSSAKA BUTTON LISTENER FOR PURCHASING MOUSSAKA
        //https://www.w3schools.com/java/java_methods.asp
        //https://stackoverflow.com/questions/25803727/android-setonclicklistener-method-how-does-it-work
        moussakaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                offers_purchase_init(v);
            }
        });
    }
    //CROSSES OUT OFFERS DISCOUNTED PRICE WITH A LINE TO INDICATE THAT THIS IS NO LONGER THE CURRENT PRICE
    //https://www.w3schools.com/java/java_methods.asp
    private void offers_discount_init() {
        //https://www.tabnine.com/code/java/methods/android.widget.TextView/setPaintFlags
        souvlakiItemPriceOriginal.setPaintFlags(souvlakiItemPriceOriginal.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
        //https://www.tabnine.com/code/java/methods/android.widget.TextView/setPaintFlags
        dolmadesItemPriceOriginal.setPaintFlags(dolmadesItemPriceOriginal.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
        //https://www.tabnine.com/code/java/methods/android.widget.TextView/setPaintFlags
        moussakaItemPriceOriginal.setPaintFlags(moussakaItemPriceOriginal.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
    }
    //PURCHASE FUNCTION FOR THE DISCOUNTED FOOD AVAILABLE TO THE USER
    //https://www.w3schools.com/java/java_methods.asp
    public void offers_purchase_init(View offers_view) {
        //STRING VALUES FOR DISPLAYING THE ITEMS AND THE PRICES
        String offers_item = "";
        String offers_price = "";
        //OFFERS VIEWS OF FOOD TO DISPLAY
        //SOUVLAKI FOOD DISPLAY
        if (offers_view.getId() == R.id.souvlaki_button) {
            //https://stackoverflow.com/questions/1974489/how-to-get-text-from-edittext
            offers_item = souvlakiItem.getText().toString();
            offers_price = souvlakiItemPriceDiscounted.getText().toString();
        //DOLMADES FOOD DISPLAY
        } else if (offers_view.getId() == R.id.dolmades_button) {
            //https://stackoverflow.com/questions/1974489/how-to-get-text-from-edittext
            offers_item = dolmadesItem.getText().toString();
            offers_price = dolmadesItemPriceDiscounted.getText().toString();
        //MOUSSAKA FOOD DISPLAY
        } else if (offers_view.getId() == R.id.moussaka_button) {
            //https://stackoverflow.com/questions/1974489/how-to-get-text-from-edittext
            offers_item = moussakaItem.getText().toString();
            offers_price = moussakaItemPriceDiscounted.getText().toString();
        }
        //CONFIRMATION CALL FOR FINAL PURCHASE
        //https://www.w3schools.com/java/java_methods.asp
        offers_confirm_init(offers_item, offers_price);
    }
    //CONFIRMATION FOR PURCHASE OF FOOD FOR THE USER
    //https://www.w3schools.com/java/java_methods.asp
    private void offers_confirm_init(String itemName, String itemPrice) {
        //https://developer.android.com/develop/ui/views/components/dialogs
        AlertDialog.Builder offers_builder = new AlertDialog.Builder(this);
        //https://developer.android.com/develop/ui/views/components/dialogs
        offers_builder.setTitle("Confirm Your Order");
        //https://developer.android.com/develop/ui/views/components/dialogs
        offers_builder.setMessage("Are you sure you'd like to order " + itemName + " for " + itemPrice + "?");
        //https://developer.android.com/develop/ui/views/components/dialogs
        offers_builder.setPositiveButton("Yes", (dialog, which) -> {
            //https://developer.android.com/guide/topics/ui/notifiers/toasts
            Toast.makeText(offersAct.this, "Thank you very much for your patronage!", Toast.LENGTH_SHORT).show();
        });
        //https://developer.android.com/develop/ui/views/components/dialogs
        offers_builder.setNegativeButton("No", (dialog, which) -> dialog.dismiss());
        //https://developer.android.com/develop/ui/views/components/dialogs
        AlertDialog offers_dialog = offers_builder.create();
        //https://www.w3schools.com/java/java_methods.asp
        offers_dialog.show();
    }
}
