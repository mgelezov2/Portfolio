package com.example.myapplication;

//IMPORTS FOR FOOD MENU ACTIVITY
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;
//FOOD ACTIVITY CLASS THAT EXTENDS APPCOMPATACTIVITY
public class foodMenuAct extends AppCompatActivity{
    //RESOURCES FOR DISPLAYING THE FOOD MENU
    //THESE ALLOW FOR VALUES TO BE DISPLAYED AND INTERACTIVE
    //https://www.w3schools.com/java/java_arraylist.asp
    private List<menuModel> food_items_display = new ArrayList<>();
    //https://developer.android.com/reference/android/widget/TextView
    private TextView souvlakiItem, souvlakiItemDesc, souvlakiItemPrice;
    //https://developer.android.com/reference/android/widget/ImageView
    private ImageView souvlakiImg;
    //https://developer.android.com/develop/ui/views/components/button
    private Button souvlakiButton;
    //https://developer.android.com/reference/android/widget/TextView
    private TextView dolmadesItem, dolmadesItemDesc, dolmadesItemPrice;
    //https://developer.android.com/reference/android/widget/ImageView
    private ImageView dolmadesImg;
    private Button dolmadesButton;
    //https://developer.android.com/reference/android/widget/TextView
    private TextView moussakaItem, moussakaItemDesc, moussakaItemPrice;
    //https://developer.android.com/reference/android/widget/ImageView
    private ImageView moussakaImg;
    //https://developer.android.com/develop/ui/views/components/button
    private Button moussakaButton;
    //ONCREATE FOR FOOD MENU ACTIVITY
    @Override
    //https://developer.android.com/reference/android/app/Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_menu);
        //METHODS CALLED FOR FOOD MENU ACTIVITY
        //https://codegym.cc/groups/posts/how-to-call-a-method-in-java-
        food_menu_init();
        food_menu_ui_init();
        food_menu_listeners_init();
    }
    //FOOD MENU DISPLAY LIST THAT HAS STORED VALUES OF THE FOOD AVAILABLE
    //https://www.w3schools.com/java/java_methods.asp
    private void food_menu_init() {
        //https://www.w3schools.com/java/java_arraylist.asp
        food_items_display.add(new menuModel("Souvlaki", "Ing: Chicken, minced garlic, Oregano, Honey, Salt, Black pepper, Zest of lemon", "€12.99", R.drawable.souvlaki));
        //https://www.w3schools.com/java/java_arraylist.asp
        food_items_display.add(new menuModel("Dolmades", "Ing: Spring Onion, Grain rice, Parsley, Dill, Mint Leaves, Capers, Vine leaves", "€7.99", R.drawable.dolmades));
        //https://www.w3schools.com/java/java_arraylist.asp
        food_items_display.add(new menuModel("Moussaka", "Ing: Aubergines, Lamb mince, Chopped tomatoes, Potatoes", "€19.99", R.drawable.moussaka));
    }
    //FOOD MENU DISPLAY FOR FOOD AVAILABLE TO THE USER
    //https://www.w3schools.com/java/java_methods.asp
    private void food_menu_ui_init() {
        //SOUVLAKI FOOD DISPLAY
        //https://developer.android.com/reference/android/view/View
        souvlakiItem = findViewById(R.id.souvlaki_item);
        souvlakiItemDesc = findViewById(R.id.souvlaki_item_desc);
        souvlakiItemPrice = findViewById(R.id.souvlaki_item_price);
        souvlakiImg = findViewById(R.id.souvlaki_img);
        souvlakiButton = findViewById(R.id.souvlaki_button);
        get_menu_items(food_items_display.get(0), souvlakiItem, souvlakiItemDesc, souvlakiItemPrice, souvlakiImg);
        //DOLMADES FOOD DISPLAY
        //https://developer.android.com/reference/android/view/View
        dolmadesItem = findViewById(R.id.dolmades_item);
        dolmadesItemDesc = findViewById(R.id.dolmades_item_desc);
        dolmadesItemPrice = findViewById(R.id.dolmades_item_price);
        dolmadesImg = findViewById(R.id.dolmades_img);
        dolmadesButton = findViewById(R.id.dolmades_button);
        get_menu_items(food_items_display.get(1), dolmadesItem, dolmadesItemDesc, dolmadesItemPrice, dolmadesImg);
        //MOUSSAKA FOOD DISPLAY
        //https://developer.android.com/reference/android/view/View
        moussakaItem = findViewById(R.id.moussaka_item);
        moussakaItemDesc = findViewById(R.id.moussaka_item_desc);
        moussakaItemPrice = findViewById(R.id.moussaka_item_price);
        moussakaImg = findViewById(R.id.moussaka_img);
        moussakaButton = findViewById(R.id.moussaka_button);
        get_menu_items(food_items_display.get(2), moussakaItem, moussakaItemDesc, moussakaItemPrice, moussakaImg);
    }
    //FOOD MENU BUTTON EVENT LISTENERS
    //https://www.w3schools.com/java/java_methods.asp
    //https://stackoverflow.com/questions/25803727/android-setonclicklistener-method-how-does-it-work
    private void food_menu_listeners_init() {
        //PURCHASE FOR THE SOUVLAKI AT A NON-DISCOUNTED PRICE
        souvlakiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                food_menu_purchase_init(v);
            }
        });
        //PURCHASE FOR THE DOLMADES AT A NON-DISCOUNTED PRICE
        dolmadesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                food_menu_purchase_init(v);
            }
        });
        //PURCHASE FOR THE MOUSSAKA AT A NON-DISCOUNTED PRICE
        moussakaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                food_menu_purchase_init(v);
            }
        });
    }
    //PURCHASE FUNCTION THAT ALLOWS THE USER TO FINALIZE THEIR PURCHASE OF THE FOOD THEY ORDER
    //https://www.w3schools.com/java/java_methods.asp
    public void food_menu_purchase_init(View menu_view) {
        String menu_item = "";
        String menu_price = "";
        if (menu_view.getId() == R.id.souvlaki_button) {
            //https://stackoverflow.com/questions/1974489/how-to-get-text-from-edittext
            menu_item = souvlakiItem.getText().toString();
            menu_price = souvlakiItemPrice.getText().toString();
        } else if (menu_view.getId() == R.id.dolmades_button) {
            //https://stackoverflow.com/questions/1974489/how-to-get-text-from-edittext
            menu_item = dolmadesItem.getText().toString();
            menu_price = dolmadesItemPrice.getText().toString();
        } else if (menu_view.getId() == R.id.moussaka_button) {
            //https://stackoverflow.com/questions/1974489/how-to-get-text-from-edittext
            menu_item = moussakaItem.getText().toString();
            menu_price = moussakaItemPrice.getText().toString();
        }
        //https://www.w3schools.com/java/java_methods.asp
        food_menu_confirm_init(menu_item, menu_price);
    }
    //CONFIRMATION OF THE USER PURCHASE
    //https://www.w3schools.com/java/java_methods.asp
    private void food_menu_confirm_init(String itemName, String itemPrice) {
        //https://developer.android.com/develop/ui/views/components/dialogs
        AlertDialog.Builder offers_builder = new AlertDialog.Builder(this);
        //https://developer.android.com/develop/ui/views/components/dialogs
        offers_builder.setTitle("Confirm Your Order");
        //https://developer.android.com/develop/ui/views/components/dialogs
        offers_builder.setMessage("Are you sure you'd like to order " + itemName + " for " + itemPrice + "?");
        //https://developer.android.com/develop/ui/views/components/dialogs
        offers_builder.setPositiveButton("Yes", (dialog, which) -> {
            //https://developer.android.com/guide/topics/ui/notifiers/toasts
            Toast.makeText(foodMenuAct.this, "Thank you very much for your patronage!", Toast.LENGTH_SHORT).show();
        });
        //https://developer.android.com/develop/ui/views/components/dialogs
        offers_builder.setNegativeButton("No", (dialog, which) -> dialog.dismiss());
        //https://developer.android.com/develop/ui/views/components/dialogs
        AlertDialog offers_dialog = offers_builder.create();
        //https://www.w3schools.com/java/java_methods.asp
        offers_dialog.show();
    }
    //FOOD MENU VALUES GETTER FUNCTION
    //https://www.w3schools.com/java/java_encapsulation.asp
    private void get_menu_items(menuModel item, TextView name, TextView desc, TextView price, ImageView img) {
        //https://stackoverflow.com/questions/19452269/android-set-text-to-textview
        name.setText(item.getProductName());
        //https://stackoverflow.com/questions/19452269/android-set-text-to-textview
        desc.setText(item.getProductDescription());
        //https://stackoverflow.com/questions/19452269/android-set-text-to-textview
        price.setText(item.getProductPrice());
        //https://stackoverflow.com/questions/12646354/android-imageview-setimageresource-in-code
        img.setImageResource(item.getProductImage());
    }

}
