package com.example.myapplication;
//IMPORTS FOR FEEDBACK ACTIVITY
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
//FEEDBACK CLASS WHICH EXTENDS APPCOMPATACTIVITY
public class feedbackAct extends AppCompatActivity{
    //ONCREATE FUNCTION FOR FEEDBACK ACTIVITY
    //ALLOWS USER TO SEND FEEDBACK THAT CHECKS IF FEEDBACK IS NOT EMPTY IT WILL SEND A THANK YOU MESSAGE ONCE SUBMITTED
    //BUT IF IT IS EMPTY IT WILL PROMPT THE USER TO ENTER THEIR FEEDBACK.
    @Override
    //https://developer.android.com/reference/android/app/Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //VIEW FOR FEEDBACK
        //https://developer.android.com/reference/android/view/View
        setContentView(R.layout.activity_feedback_menu);
        //https://stackoverflow.com/questions/30447545/how-to-access-edittext-type-in-android-studio
        EditText feedback_input = findViewById(R.id.editText_feedback);
        //SUBMIT FEEDBACK BUTTON
        //https://developer.android.com/develop/ui/views/components/button
        Button submit_feedback = findViewById(R.id.button_submit_feedback);
        //https://stackoverflow.com/questions/25803727/android-setonclicklistener-method-how-does-it-work
        submit_feedback.setOnClickListener(v -> {
            String feedback_value = feedback_input.getText().toString();
            if (!feedback_value.isEmpty()) {
                //https://developer.android.com/guide/topics/ui/notifiers/toasts#java
                Toast.makeText(feedbackAct.this, "Thank you very much for your feedback!", Toast.LENGTH_SHORT).show();
            } else {
                //https://developer.android.com/guide/topics/ui/notifiers/toasts#java
                Toast.makeText(feedbackAct.this, "Please let us know your thoughts and opinions!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
