package com.example.myapplication;
//MODEL CLASS FOR MVC PATTERN
public class menuModel {
    //STRING VALUES FOR PRODUCTS ON THE FOOD MENU
    private String product_name;
    private String product_desc;
    private String product_price;
    private int product_image;
    //CONSTRUCTOR FOR THE MENUMODEL CLASS
    //https://www.w3schools.com/java/java_constructors.asp
    public menuModel(String product_name, String product_desc, String product_price, int product_image) {
        this.product_name = product_name;
        this.product_desc = product_desc;
        this.product_price = product_price;
        this.product_image = product_image;
    }

    //GETTERS AND SETTERS METHODS FOR MENUMODEL CLASS

    //PRODUCT NAME GETTER
    //https://www.w3schools.com/java/java_encapsulation.asp
    public String getProductName() {
        return product_name;
    }
    //PRODUCT NAME SETTER
    //https://www.w3schools.com/java/java_encapsulation.asp
    public void setProductName(String product_name) {
        this.product_name = product_name;
    }
    //PRODUCT DESCRIPTION GETTER
    //https://www.w3schools.com/java/java_encapsulation.asp
    public String getProductDescription() {
        return product_desc;
    }
    //PRODUCT DESCRIPTION SETTER
    //https://www.w3schools.com/java/java_encapsulation.asp
    public void setProductDescription(String product_desc) {
        this.product_desc = product_desc;
    }
    //PRODUCT PRICE GETTER
    //https://www.w3schools.com/java/java_encapsulation.asp
    public String getProductPrice() {
        return product_price;
    }
    //PRODUCT PRICE SETTER
    //https://www.w3schools.com/java/java_encapsulation.asp
    public void setProductPrice(String product_price) {
        this.product_price = product_price;
    }
    //PRODUCT IMAGE GETTER
    //https://www.w3schools.com/java/java_encapsulation.asp
    public int getProductImage() {
        return product_image;
    }
    //PRODUCT IMAGE SETTER
    //https://www.w3schools.com/java/java_encapsulation.asp
    public void setProductImage(int product_image) {
        this.product_image = product_image;
    }

}
