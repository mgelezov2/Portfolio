package com.example.myapplication;
//IMPORTS FOR ORDER ACTIVITY
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
//ORDER ACTIVITY CLASS THAT EXTENDS APPCOMPATACTIVITY
public class orderAct extends AppCompatActivity {
    //ORDER ACTIVITY INTERACTIVE TEXT BOXES FOR THE USER

    //CUSTOMER NAME EDIT TEXT
    //https://stackoverflow.com/questions/1974489/how-to-get-text-from-edittext
    private EditText customerNameEditText;
    //CUSTOMER ADDRESS EDIT TEXT
    //https://stackoverflow.com/questions/1974489/how-to-get-text-from-edittext
    private EditText customerAddressEditText;
    //HOW MANY PORTIONS EDIT TEXT
    //https://stackoverflow.com/questions/1974489/how-to-get-text-from-edittext
    private EditText customerPerPersonEditText;
    //SUBMIT ORDER BUTTON
    //https://developer.android.com/develop/ui/views/components/button
    private Button orderSubmissionButton;
    //ONCREATE FUNCTION FOR ORDER ACTIVITY
    //https://developer.android.com/reference/android/app/Activity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_menu);
        //https://codegym.cc/groups/posts/how-to-call-a-method-in-java-
        order_ui_init();
        order_listener_init();
    }
    //ORDER ACTIVITY DISPLAY TEXT BOXES
    //https://www.w3schools.com/java/java_methods.asp
    private void order_ui_init() {
        customerNameEditText = findViewById(R.id.customer_name);
        customerAddressEditText = findViewById(R.id.customer_address);
        customerPerPersonEditText = findViewById(R.id.customer_per_person);
        orderSubmissionButton = findViewById(R.id.order_submission);
    }
    //ORDER ACTIVITY LISTENER FOR SUBMIT BUTTON
    //https://www.w3schools.com/java/java_methods.asp
    private void order_listener_init() {
        //https://developer.android.com/reference/android/view/View
        //https://developer.android.com/reference/android/view/View.OnClickListener
        //https://stackoverflow.com/questions/25803727/android-setonclicklistener-method-how-does-it-work
        orderSubmissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check_if_submitted();
            }
        });
    }
    // CHECK IF THE ORDER HAS BEING SUBMITTED
    //https://www.w3schools.com/java/java_methods.asp
    private void check_if_submitted() {
       //https://stackoverflow.com/questions/1974489/how-to-get-text-from-edittext
        String customerName = customerNameEditText.getText().toString();
        //https://stackoverflow.com/questions/1974489/how-to-get-text-from-edittext
        String customerAddress = customerAddressEditText.getText().toString();
        //https://stackoverflow.com/questions/1974489/how-to-get-text-from-edittext
        String customerPerPerson = customerPerPersonEditText.getText().toString();
        //https://developer.android.com/guide/topics/ui/notifiers/toasts
        if (check_if_input_valid(customerName, customerAddress, customerPerPerson)) {
            Toast.makeText(orderAct.this, "Order submitted", Toast.LENGTH_SHORT).show();
        }
    }
    // CHECK IF THE DETAILS ENTERED ARE VALID
    //https://www.w3schools.com/java/java_methods.asp
    private boolean check_if_input_valid(String name, String address, String perPerson) {
        if (name.isEmpty()) {
            display_notice_to_user("Please enter your name");
            return false;
        }
        if (address.isEmpty()) {
            display_notice_to_user("Please enter your address");
            return false;
        }
        if (perPerson.isEmpty()) {
            display_notice_to_user("Please enter the amount you'd like to order");
            return false;
        }
        return true;
    }
    //DISPLAY NOTICE TO USER
    //https://www.w3schools.com/java/java_methods.asp

    private void display_notice_to_user(String message) {
        //https://developer.android.com/guide/topics/ui/notifiers/toasts
        Toast.makeText(orderAct.this, message, Toast.LENGTH_SHORT).show();
    }
}
