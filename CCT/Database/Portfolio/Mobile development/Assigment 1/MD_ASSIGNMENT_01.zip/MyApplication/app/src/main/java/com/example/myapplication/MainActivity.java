package com.example.myapplication;
//IMPORTS FOR MAIN ACTIVITY
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
//MAIN ACTIVITY CLASS THAT EXTENDS APPCOMPATACTIVITY
public class MainActivity extends AppCompatActivity {
    //ONCREATE FUNCTION FOR MAIN ACTIVITY
    //FOUR BUTTONS TO FOUR NAVIGATIONS, FOOD MENU, OFFERS MENU, FEEDBACK MENU AND ORDERS MENU
    //ALL CONNECTED TO ONCLICK FUNCTIONS THAT HAVE DESIGNATED ACTIVITIES, FOODMENUACT, OFFERSACT, FEEDBACKACT AND ORDERACT
    @Override
    //https://developer.android.com/reference/android/app/Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //BUTTONS FOR NAVIGATION
        //https://developer.android.com/develop/ui/views/components/button
        Button menuButton = findViewById(R.id.menu_nav_button);
        //https://developer.android.com/develop/ui/views/components/button
        Button offersButton = findViewById(R.id.offers_nav_button);
        //https://developer.android.com/develop/ui/views/components/button
        Button feedbackButton = findViewById(R.id.feedback_nav_button);
        //https://developer.android.com/develop/ui/views/components/button
        Button orderButton = findViewById(R.id.orders_nav_button);
        //FOOD MENU BUTTON LISTENER
        //https://developer.android.com/develop/ui/views/components/button
        //https://stackoverflow.com/questions/10231309/android-button-onclick
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, foodMenuAct.class));
            }
            
        });
        //OFFERS BUTTON LISTENER
        //https://developer.android.com/develop/ui/views/components/button
        //https://stackoverflow.com/questions/10231309/android-button-onclick
        offersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, offersAct.class));
            }
        });
        //FEEDBACK BUTTON LISTENER
        //https://developer.android.com/develop/ui/views/components/button
        //https://stackoverflow.com/questions/10231309/android-button-onclick
        feedbackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, feedbackAct.class));
            }
        });
        //ORDER BUTTON LISTENER
        //https://developer.android.com/develop/ui/views/components/button
        //https://stackoverflow.com/questions/10231309/android-button-onclick
        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, orderAct.class));
            }
        });
    }
}
