from django.contrib import admin
from .models import Drinks

# Register your models here.
admin.site.register(Drinks)
